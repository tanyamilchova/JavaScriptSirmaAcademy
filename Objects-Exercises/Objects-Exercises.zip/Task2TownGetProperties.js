let pers={name:"Sofia ",population:2000000,country:"Bulgaria"};
function getData(pers){
    console.log("name->"+pers.name);
    console.log("population->"+pers.population);
    console.log("country->"+pers.country);
}
 getData(pers);