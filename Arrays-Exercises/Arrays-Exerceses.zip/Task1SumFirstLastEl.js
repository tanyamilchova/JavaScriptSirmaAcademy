let arr=[1,5,8,14];
console.log(arr[0]+arr[arr.length-1]);
