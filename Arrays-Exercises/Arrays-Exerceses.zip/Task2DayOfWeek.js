let arrDays=[ "Monday", "Tusday", "Wednesday", "Thirstday", "Friday", "Satruday", "Sunday"];
let num=3;
console.log(arrDays[num-1]);