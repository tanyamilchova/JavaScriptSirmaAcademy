let arr=[ "a","b","c","d","e"];
let revertedArr=[];
for (let index = arr.length-1; index >=0; index--) {
    revertedArr.push(arr[index]);
    
}
console.log(revertedArr);