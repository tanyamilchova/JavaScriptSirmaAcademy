let num=3;
let arr=[10,20,30,40,50];
let newArr=[];
console.log(arr.length);
for (let index = num-1; index>=0; index--) {
   newArr.push(arr[index]);
  
}
console.log(newArr);