// IIFE
(function() {
    console.log('IIFE');
})();

// IIAE
(() => {
    console.log('IIAE');
})();
