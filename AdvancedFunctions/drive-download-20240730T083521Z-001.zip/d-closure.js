function outer(number) {
    let current = 'outer';
    let another = 'alsdjkfasd';
    console.log('outer - ' + number);

    return function inner(number) {
        console.log(current);
        console.log('Inner - ' + number);
    }
}

const inner = outer(10);

inner(20);

// Counter
function buildCounter(initialValue = 0) {
    let currentCount = initialValue;

    return function() {
        console.log(++currentCount);
    }
}

const firstCounter = buildCounter();
const secondCounter = buildCounter(10);
firstCounter();
secondCounter();
secondCounter();
firstCounter();
firstCounter();
firstCounter();


