function sum(num1,num2) {
    return num1+num2;
}
function subtract(num3){
    let result=sum(23,6);
    return result-num3;
}
console.log(subtract(10));